<?php return array('dependencies' => array(), 'version' => 'd08d0cc7ba43fbb8c88e');
