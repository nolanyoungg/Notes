<?php return array('dependencies' => array(), 'version' => '0d604fa45a1728ec06ea');
