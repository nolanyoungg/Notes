# Nolan Young Theme Template 01

A production-oriented **classic WordPress theme** for WordPress 7.0 that combines the PHP template hierarchy with modern WordPress features such as `theme.json` version 3, block patterns, editor styles, registered block styles, accessible navigation, and a standards-based webpack build.

This document is the authoritative operating manual for the theme. It explains what the theme owns, what it deliberately does not own, how WordPress loads it, how the source and compiled assets are organized, how the webpack pipeline works, which commands are safe to run, how to package a release, and which checks must pass before deployment.

---

## Table of contents

1. [Project status](#project-status)
2. [Theme classification](#theme-classification)
3. [Requirements](#requirements)
4. [Production installation](#production-installation)
5. [Source-development setup](#source-development-setup)
6. [Architecture boundaries](#architecture-boundaries)
7. [High-level request flow](#high-level-request-flow)
8. [Complete directory guide](#complete-directory-guide)
9. [Root WordPress files](#root-wordpress-files)
10. [PHP bootstrap and modules](#php-bootstrap-and-modules)
11. [Template hierarchy](#template-hierarchy)
12. [Page templates](#page-templates)
13. [Template parts](#template-parts)
14. [Companion plugin integration](#companion-plugin-integration)
15. [Primary navigation and mega menus](#primary-navigation-and-mega-menus)
16. [Front-page composition](#front-page-composition)
17. [`theme.json` design system](#themejson-design-system)
18. [SCSS architecture](#scss-architecture)
19. [JavaScript architecture](#javascript-architecture)
20. [Webpack and build system](#webpack-and-build-system)
21. [NPM commands](#npm-commands)
22. [Generated asset metadata](#generated-asset-metadata)
23. [WordPress asset enqueueing](#wordpress-asset-enqueueing)
24. [Editor styles](#editor-styles)
25. [Block patterns and block styles](#block-patterns-and-block-styles)
26. [Customizer settings](#customizer-settings)
27. [Internationalization](#internationalization)
28. [Security requirements](#security-requirements)
29. [Accessibility requirements](#accessibility-requirements)
30. [PHP coding standards](#php-coding-standards)
31. [Testing and validation](#testing-and-validation)
32. [Local debugging](#local-debugging)
33. [Release and packaging workflow](#release-and-packaging-workflow)
34. [Production ZIP contents](#production-zip-contents)
35. [Common development workflows](#common-development-workflows)
36. [Troubleshooting](#troubleshooting)
37. [Non-negotiable maintenance rules](#non-negotiable-maintenance-rules)
38. [Official WordPress references](#official-wordpress-references)

---

## Project status

| Property | Value |
|---|---|
| Theme name | Nolan Young Theme Template 01 |
| Theme slug | `nolan-young-theme-template-01` |
| Current version | `1.2.3` |
| Theme type | Classic PHP theme with `theme.json` |
| Minimum WordPress | WordPress 7.0 |
| Tested WordPress | WordPress 7.0 |
| Minimum PHP | PHP 7.4 |
| Text domain | `nolan-young-theme-template-01` |
| Node.js for source development | Node.js 20.9 or newer |
| npm for source development | npm 10 or newer |
| JavaScript/CSS build | `@wordpress/scripts` and webpack |
| Companion plugin | `nolan-young-core` |
| License | GPL-2.0-or-later |

The WordPress and PHP values above must match the metadata in `style.css`. The npm package version must also match the theme version. `npm run validate` checks these relationships.

---

## Theme classification

This is a **classic theme**, not a full block theme.

A classic theme primarily uses PHP template files such as:

```text
front-page.php
home.php
page.php
single.php
archive.php
404.php
```

The theme also uses modern WordPress functionality:

- `theme.json` version 3 for global settings and styles.
- Block editor styles through `add_editor_style()`.
- Theme patterns stored in `/patterns`.
- Registered block style variations.
- Core enqueue APIs for CSS and JavaScript.
- A webpack build based on the WordPress-maintained `@wordpress/scripts` package.

The presence of `theme.json` does not convert the project into a block theme. The PHP template hierarchy remains the request-rendering system.

---

## Requirements

### Runtime requirements

The installed production theme requires:

- WordPress 7.0 or newer.
- PHP 7.4 or newer.
- A web server supported by WordPress.
- A normal WordPress database connection.
- The `nolan-young-core` companion plugin when Service content, contact forms, newsletter forms, access rules, or privacy integrations are required.

Visitors do **not** need Node.js, npm, Composer, webpack, or the source directory. Those tools are for development only.

### Development requirements

To edit SCSS or JavaScript source, install:

- Node.js 20.9 or newer.
- npm 10 or newer.
- Git.
- A local WordPress 7.0 development site.
- PHP 7.4 or newer for syntax checks.
- Composer 2 for PHP standards, compatibility checks, and PHPUnit.

Recommended development tools:

- Local, wp-env, Docker, or another isolated WordPress development environment.
- Visual Studio Code.
- Theme Check.
- WordPress Theme Unit Test data.
- A mail-capture plugin for testing plugin-generated email.
- Browser developer tools.

### Confirm installed versions

```bash
node --version
npm --version
php --version
git --version
```

The project declares its supported Node and npm versions in `package.json` under `engines`.

---

## Production installation

Use the installable production ZIP, not the source ZIP.

### Install the companion plugin first

1. Sign in to WordPress Admin.
2. Go to **Plugins → Add Plugin → Upload Plugin**.
3. Upload `nolan-young-core.zip`.
4. Select **Install Now**.
5. Activate **Nolan Young Core**.

### Install the theme

1. Go to **Appearance → Themes → Add New → Upload Theme**.
2. Upload `nolan-young-theme-template-01.zip`.
3. Select **Install Now**.
4. Activate **Nolan Young Theme Template 01**.
5. Clear page, object, browser, CDN, and host-level caches.

### Complete initial WordPress configuration

After activation:

1. Go to **Settings → Reading**.
2. Assign a static front page if the site uses one.
3. Assign a Posts page if the site uses the blog index.
4. Go to **Appearance → Menus** or the applicable WordPress navigation interface.
5. Confirm that a menu is assigned to **Primary Navigation**.
6. Confirm that the order is Services, About, Work, Blog unless the project requires a deliberate change.
7. Configure the site logo through **Appearance → Customize → Site Identity**.
8. Create a Contact page at `/contact/` or update the header CTA URL in code.
9. Configure the footer menu and footer widget area if used.
10. Confirm permalinks under **Settings → Permalinks**.

---

## Source-development setup

The source package includes development files that are intentionally omitted from the production ZIP.

### First-time setup

Open a terminal in the theme root—the directory that contains `package.json`:

```text
wp-content/themes/nolan-young-theme-template-01/
```

Install the exact dependency tree from `package-lock.json`:

```bash
npm ci
composer install
```

Use `npm ci` for normal development and CI. It installs the locked versions and fails when `package.json` and `package-lock.json` disagree. The committed lockfile is registry-neutral and must not contain private or environment-specific registry URLs.

Use `npm install` only when intentionally adding, removing, or updating dependencies. Any dependency change must include the resulting `package-lock.json` change in the same commit.

### Windows PowerShell example

```powershell
Set-Location "C:\Users\NolanYoung\Local Sites\cvc\app\public\wp-content\themes\nolan-young-theme-template-01"
npm ci
composer install
npm run build
```

### macOS or Linux example

```bash
cd /path/to/wordpress/wp-content/themes/nolan-young-theme-template-01
npm ci
composer install
npm run build
```

### Verify the checkout

```bash
npm run build
```

A clean checkout is not ready for review until both locked dependency trees are installed and `npm test` passes. `npm test` runs the clean asset build, dependency audit, PHP_CodeSniffer/PHPCompatibility rules, and source-level PHPUnit tests.

---

## Architecture boundaries

The most important architectural rule is:

> The theme owns presentation. The companion plugin owns persistent application functionality.

### The theme may own

- PHP template hierarchy files.
- HTML structure and semantic landmarks.
- Frontend CSS and JavaScript.
- Theme-specific image assets.
- Navigation presentation and accessible dropdown behavior.
- `theme.json` settings and styles.
- Block patterns.
- Block style variations.
- Registered navigation locations.
- Registered widget areas.
- Theme supports.
- Presentation-only Customizer settings.
- Templates for content types registered by a plugin.
- Presentation integrations with the companion plugin.

### The theme must not own

- Custom post type registration.
- Custom taxonomy registration.
- Contact-form submission processing.
- Newsletter subscription processing.
- Email delivery.
- Persistent inquiry records.
- Authentication or authorization rules.
- REST endpoints for application functionality.
- Database tables.
- API credentials.
- Payment processing.
- Business data that must survive a theme change.

### Companion plugin responsibility

The `nolan-young-core` plugin owns functionality that must remain available when the active theme changes, including:

- The `ny_service` post type.
- The `ny_service_category` taxonomy.
- Contact form processing.
- Newsletter form processing.
- Stored inquiry/subscription records.
- Access-control rules and 403 status handling.
- WordPress personal-data export and erasure integrations.

The theme may render plugin data, but it must not duplicate the plugin’s application logic.

---

## High-level request flow

A typical frontend request follows this sequence:

1. WordPress boots core.
2. Active plugins load, including `nolan-young-core`.
3. WordPress loads this theme’s `functions.php`.
4. `functions.php` loads the focused modules under `/inc`.
5. Hooks register theme support, menus, widget areas, assets, block styles, and presentation filters.
6. WordPress resolves the request through the template hierarchy.
7. The selected root template calls `get_header()`.
8. `header.php` renders the site header and WordPress-managed primary navigation.
9. The root template loads focused template parts.
10. WordPress runs the Loop for the current query where applicable.
11. The template calls `get_footer()`.
12. Enqueued assets are printed through `wp_head()` and `wp_footer()`.
13. JavaScript progressively enhances navigation, mega menus, and accordions.

Templates must not manually load CSS or JavaScript with hardcoded `<link>` or `<script>` tags.

---

## Complete directory guide

```text
nolan-young-theme-template-01/
├── accessibility/
│   └── README.md
├── assets/
│   ├── css/
│   │   ├── bundle-rtl.css
│   │   ├── bundle.asset.php
│   │   ├── bundle.css
│   │   ├── editor-rtl.css
│   │   ├── editor.asset.php
│   │   └── editor.css
│   ├── icons/
│   │   ├── arrow-right.svg
│   │   ├── icon1.svg
│   │   └── README.md
│   ├── images/
│   │   ├── hero/
│   │   │   └── README.md
│   │   ├── navigation/
│   │   │   ├── about-us.svg
│   │   │   ├── blog-placeholder.svg
│   │   │   ├── careers.svg
│   │   │   ├── future-work.svg
│   │   │   ├── meet-the-team.svg
│   │   │   ├── service-1.svg
│   │   │   ├── service-2.svg
│   │   │   ├── service-3.svg
│   │   │   └── service-4.svg
│   │   ├── portfolio/
│   │   │   └── README.md
│   │   └── texture/
│   │       └── README.md
│   └── js/
│       ├── bundle.asset.php
│       └── bundle.js
├── build/
│   ├── clean.js
│   ├── dev.js
│   ├── package-theme.js
│   ├── preflight.js
│   └── validate.js
├── docs/
│   ├── accessibility.md
│   ├── architecture.md
│   ├── customization.md
│   ├── getting-started.md
│   └── release-process.md
├── inc/
│   ├── integrations/
│   │   └── nolan-young-core.php
│   ├── block-styles.php
│   ├── customizer.php
│   ├── enqueue.php
│   ├── navigation.php
│   ├── setup.php
│   ├── template-functions.php
│   └── template-tags.php
├── languages/
│   └── nolan-young-theme-template-01.pot
├── page-templates/
│   ├── template-about-us.php
│   ├── template-blog-landing.php
│   ├── template-blog.php
│   ├── template-contact.php
│   ├── template-policy.php
│   ├── template-service-detail.php
│   ├── template-services.php
│   ├── template-single-service.php
│   └── template-work.php
├── patterns/
│   ├── call-to-action.php
│   ├── featured-work.php
│   ├── hero.php
│   ├── services-grid.php
│   └── testimonials.php
├── src/
│   ├── js/
│   │   ├── components/
│   │   │   ├── accordion.js
│   │   │   ├── mega-menu.js
│   │   │   └── navigation.js
│   │   ├── utilities/
│   │   │   └── dom.js
│   │   └── main.js
│   └── scss/
│       ├── abstracts/
│       │   ├── _functions.scss
│       │   ├── _mixins.scss
│       │   └── _variables.scss
│       ├── base/
│       │   ├── _accessibility.scss
│       │   ├── _form-elements.scss
│       │   ├── _newsletter.scss
│       │   ├── _reset.scss
│       │   └── _typography.scss
│       ├── components/
│       │   ├── _accordion.scss
│       │   ├── _badges.scss
│       │   ├── _before-after.scss
│       │   ├── _buttons.scss
│       │   ├── _cards.scss
│       │   ├── _carousel.scss
│       │   ├── _form-components.scss
│       │   ├── _mega-menu.scss
│       │   └── _portfolio-filter.scss
│       ├── layout/
│       │   ├── _container.scss
│       │   ├── _footer.scss
│       │   ├── _grid.scss
│       │   ├── _header.scss
│       │   └── _sections.scss
│       ├── pages/
│       │   ├── _about-us.scss
│       │   ├── _blog.scss
│       │   ├── _contact.scss
│       │   ├── _error.scss
│       │   ├── _homepage.scss
│       │   ├── _policy.scss
│       │   ├── _search.scss
│       │   ├── _service-detail.scss
│       │   ├── _services.scss
│       │   └── _work.scss
│       ├── editor.scss
│       └── main.scss
├── template-parts/
│   ├── content/
│   │   ├── content-none.php
│   │   ├── content-page.php
│   │   ├── content-policy.php
│   │   ├── content-post.php
│   │   ├── content-search.php
│   │   ├── content-single.php
│   │   └── content.php
│   ├── errors/
│   │   └── content-403.php
│   ├── footer/
│   │   └── footer-widgets.php
│   ├── front-page/
│   │   ├── content-all-services.php
│   │   ├── content-blog-preview.php
│   │   ├── content-featured-work.php
│   │   ├── content-process.php
│   │   ├── content-service-highlight.php
│   │   ├── content-single-service-highlight.php
│   │   ├── content-style-pillars.php
│   │   └── content-testimonials.php
│   ├── global/
│   │   ├── content-brand-statement.php
│   │   ├── content-cta-banner.php
│   │   └── content-hero.php
│   └── header/
│       ├── mega-menu-blog.php
│       ├── mega-menu-featured.php
│       ├── mobile-navigation.php
│       ├── primary-navigation.php
│       └── site-branding.php
├── tests/
│   ├── e2e/
│   │   └── theme.spec.js
│   ├── fixtures/
│   │   └── setup-test-site.php
│   ├── integration/
│   │   ├── bootstrap.php
│   │   ├── test-assets.php
│   │   ├── test-front-page.php
│   │   ├── test-required-files.php
│   │   └── test-theme-setup.php
│   └── unit/
│       ├── bootstrap.php
│       └── Source_Architecture_Test.php
├── .editorconfig
├── .gitignore
├── .wp-env.json
├── 404.php
├── archive-ny_service.php
├── archive.php
├── CHANGELOG.md
├── comments.php
├── composer.json
├── composer.lock
├── FILE-MANIFEST.txt
├── footer.php
├── front-page.php
├── functions.php
├── header.php
├── home.php
├── index.php
├── LICENSE.txt
├── package-lock.json
├── package.json
├── page.php
├── phpcs.xml.dist
├── phpunit.integration.xml.dist
├── phpunit.xml.dist
├── playwright.config.js
├── privacy-policy.php
├── README.md
├── screenshot.png
├── search.php
├── searchform.php
├── single-ny_service.php
├── single.php
├── singular.php
├── style.css
├── taxonomy-ny_service_category.php
├── theme.json
└── webpack.config.js
```

### Source versus runtime directories

| Location | Purpose | Edit directly? | Included in production ZIP? |
|---|---|---:|---:|
| `src/js/` | JavaScript source modules | Yes | No |
| `src/scss/` | SCSS source partials | Yes | No |
| `assets/js/` | Compiled browser JavaScript | No | Yes |
| `assets/css/` | Compiled browser CSS | No | Yes |
| `assets/images/` | Runtime images | Yes | Yes |
| `assets/icons/` | Runtime icons | Yes | Yes |
| `build/` | Node helper scripts | Yes | No |
| `webpack.config.js` | Webpack configuration | Yes | No |
| `node_modules/` | Installed development dependencies | Never | No |
| `dist/` | Locally generated release ZIP | Never manually | No |

---

## Root WordPress files

### `style.css`

WordPress reads the comment header in `style.css` to register the theme. This file must remain in the theme root.

It defines:

- Theme name.
- Theme version.
- Minimum WordPress version.
- Tested WordPress version.
- Minimum PHP version.
- License.
- Text domain.
- Theme tags.

The theme’s frontend stylesheet is not authored in `style.css`; it is compiled to `assets/css/bundle.css` and enqueued through WordPress.

### `functions.php`

`functions.php` is a bootstrap file only. It loads focused modules from `/inc` using `get_theme_file_path()` and `require_once`.

Do not add large implementations directly to `functions.php`.

### `theme.json`

`theme.json` is the global design-system authority for supported WordPress settings and block/global styles.

### `screenshot.png`

The screenshot is exactly 1200×900 pixels and appears in **Appearance → Themes**.

### `CHANGELOG.md`

Every release must add a dated entry explaining meaningful user-facing, architectural, build, security, or compatibility changes.

### `LICENSE.txt`

The project is licensed under GPL version 2 or later.

### `FILE-MANIFEST.txt`

Lists every tracked source/runtime file expected in the source package, excluding local dependency and release-output directories such as `node_modules/`, `vendor/`, and `dist/`. Regenerate it whenever files are added, removed, or renamed.

### `phpunit.xml.dist`

Defines the source-level PHPUnit suite under `tests/unit/`. WordPress integration tests use `phpunit.integration.xml.dist` and `tests/integration/bootstrap.php`.

---

## PHP bootstrap and modules

`functions.php` loads these modules in order:

```php
'/inc/setup.php',
'/inc/navigation.php',
'/inc/class-nytt01-primary-nav-walker.php',
'/inc/enqueue.php',
'/inc/template-tags.php',
'/inc/template-functions.php',
'/inc/customizer.php',
'/inc/block-styles.php',
'/inc/integrations/nolan-young-core.php',
```

### `inc/setup.php`

Owns theme initialization:

- Loads the theme text domain.
- Registers supported WordPress features.
- Enables editor styles.
- Registers HTML5 markup support.
- Registers custom-logo support.
- Registers Primary and Footer menu locations.
- Registers the card image size.
- Sets compatibility content width.
- Registers the footer widget area.
- Provides the data used by the non-persistent primary-menu fallback.

Theme activation does not create or assign menus, menu items, pages, or theme modifications. Administrators explicitly assign the production menu through WordPress.

### `inc/navigation.php`

Owns presentation data and server-rendered markup for the Services, About, and Blog mega menus.

It does not process requests or store business data.

### `inc/class-nytt01-primary-nav-walker.php`

Contains the accessible `Walker_Nav_Menu` implementation used by the Primary Navigation location. Keeping the class separate from procedural navigation helpers satisfies WordPress file/class organization standards and makes the walker independently testable.

### `inc/enqueue.php`

Owns frontend asset registration and enqueueing.

It reads webpack-generated `*.asset.php` files and passes their dependencies and content-derived versions to WordPress.

### `inc/template-tags.php`

Contains reusable display functions such as:

- Post date output.
- Post author output.
- Entry-footer metadata.
- Archive pagination.

### `inc/template-functions.php`

Contains presentation hooks and filters such as:

- Body classes.
- Pingback header output.
- Navigation link attributes.
- Safe primary-menu fallback output.

### `inc/customizer.php`

Registers presentation-only front-page text settings.

### `inc/block-styles.php`

Registers theme block styles and pattern categories.

### `inc/integrations/nolan-young-core.php`

Adds theme presentation classes to companion-plugin output. It does not process forms.

---

## Template hierarchy

WordPress selects root templates according to the standard classic-theme hierarchy.

| Template | Responsibility |
|---|---|
| `front-page.php` | Site front page whenever this file is applicable |
| `home.php` | Posts index, including the page selected as the Posts page |
| `single.php` | Individual standard posts |
| `page.php` | Standard pages |
| `singular.php` | Shared singular fallback |
| `archive.php` | Date, author, category, tag, and general archives |
| `search.php` | Search-results requests |
| `404.php` | Not-found requests |
| `privacy-policy.php` | The page assigned as the WordPress Privacy Policy page |
| `index.php` | Final fallback when no more-specific template exists |
| `single-ny_service.php` | Individual Service content from the companion plugin |
| `archive-ny_service.php` | Service archive from the companion plugin |
| `taxonomy-ny_service_category.php` | Service-category taxonomy archive |

### Controller responsibility

Root templates may:

- Call `get_header()` and `get_footer()`.
- Enter the WordPress Loop.
- Load template parts.
- Call pagination or comments functions.
- Prepare small amounts of presentation data.

Root templates must not:

- Process form submissions.
- Send email.
- Register post types.
- Change authorization.
- Store business data.
- Include credentials.

### Important front-page/blog distinction

```text
front-page.php = site front page
home.php       = posts index
```

A selectable Blog page template does not replace `home.php` for the WordPress Posts page.

---

## Page templates

Selectable templates are stored in `/page-templates`.

Current templates include:

- About Us.
- Services.
- Service Detail.
- Work.
- Blog Landing.
- Contact.
- Policy.

Some compatibility templates remain for previous assignments. Do not delete or rename an assigned page template without migrating the affected pages first; WordPress stores the template filename in post metadata.

Every selectable page template must include a valid `Template Name` header and must remain presentation-only.

---

## Template parts

Template parts are reusable presentation fragments grouped by responsibility.

### `template-parts/content/`

Contains reusable post, page, search, empty-state, and policy output.

### `template-parts/global/`

Contains site-wide marketing sections such as:

- Hero.
- Brand statement.
- CTA banner.

### `template-parts/front-page/`

Contains the ordered front-page sections.

### `template-parts/header/`

Contains:

- Site branding.
- Primary navigation.
- Mobile-navigation extension point.
- Services/About featured mega menu.
- Latest-post Blog mega menu.

### `template-parts/errors/`

Contains visual error content. The companion plugin remains responsible for setting a genuine 403 response status and deciding whether access is forbidden.

### Template-part rules

Template parts may:

- Render escaped HTML.
- Use WordPress template tags.
- Receive data through the `$args` argument of `get_template_part()`.
- Load other narrowly focused template parts.

Template parts must not:

- Register hooks.
- Inspect raw request data.
- Process submissions.
- Write to the database.
- Send email.
- Perform authentication or authorization.

---

## Companion plugin integration

The theme is designed to work with `nolan-young-core` while remaining activatable without it.

### Features supplied by the plugin

- Service content model.
- Service taxonomy.
- Contact form shortcode.
- Newsletter form shortcode.
- Form submission processing.
- Inquiry/subscriber records.
- Access-control rules.
- Privacy export/erasure support.

### Shortcodes

```text
[nolan_young_contact_form]
[nolan_young_newsletter_form]
```

### Theme integration

The theme uses the plugin filter:

```php
ny_core_form_classes
```

The theme adds its presentation class without taking ownership of processing.

### Safe degradation

When the plugin is inactive:

- The theme still activates.
- Standard pages, posts, archives, navigation, patterns, and editor styles remain available.
- Service templates have no matching registered post type.
- Plugin shortcodes no longer render plugin forms.

---

## Primary navigation and mega menus

### WordPress-managed menu location

The primary navigation is registered as:

```text
primary
```

Its admin label is:

```text
Primary Navigation
```

The menu remains a normal WordPress menu. Administrators can add, remove, rename, or reorder items.

### Default order

Until an administrator assigns a primary menu, the theme renders a non-persistent fallback in this order:

1. Services
2. About
3. Work
4. Blog

The header layout is:

```text
[ Site logo ] [ Centered WordPress primary menu ] [ Contact CTA ]
```

### Mega-menu association

Services, About, and Blog can be recognized from their title, slug, or URL. For a stable explicit association, assign these menu-item CSS classes in WordPress:

```text
nytt01-mega-services
nytt01-mega-about
nytt01-mega-blog
```

Using the explicit class is recommended if the visible item label will be renamed.

To expose the **CSS Classes** field in the classic Menus screen:

1. Open **Appearance → Menus**.
2. Open **Screen Options**.
3. Enable **CSS Classes**.
4. Expand the applicable menu item.
5. Add the appropriate class.

### Mega-menu behavior

- Opens by clicking the top-level trigger.
- Only one mega menu remains open at a time.
- Clicking outside closes the open menu.
- Moving focus outside closes the open menu.
- Selecting a link closes the menu.
- `Escape` closes the menu and restores trigger focus.
- `ArrowDown` opens a trigger and moves focus into its panel.
- Reduced-motion preferences disable delayed animation behavior.
- The active/open trigger retains the active color state.
- Mobile navigation stacks the dropdown content vertically.

### Services and About structure

Desktop featured mega menus use:

```text
[ Options list: 35% ] [ Dynamic feature panel: 65% ]
```

The feature panel is on the right and contains:

- Dynamic image.
- Dynamic title.
- Dynamic description.
- Related sub-links for the active item.
- Main exploration link.

The option list is on the left. Hover, focus, and selection update the feature panel.

### Services data

Default Services items are defined by:

```php
nytt01_get_services_mega_menu_items()
```

They can be changed with:

```php
nytt01_services_mega_menu_items
```

### About data

Default About items are defined by:

```php
nytt01_get_about_mega_menu_items()
```

They can be changed with:

```php
nytt01_about_mega_menu_items
```

### Filter example

Add customization in a companion/site plugin rather than editing generated output:

```php
add_filter(
    'nytt01_services_mega_menu_items',
    function ( $items ) {
        $items[0]['title']       = 'Web Development';
        $items[0]['description'] = 'Production WordPress development and integration work.';
        $items[0]['url']         = home_url( '/services/web-development/' );

        return $items;
    }
);
```

Validate the final array shape. Each item expects:

```php
array(
    'title'       => 'Visible title',
    'description' => 'Short description',
    'image'       => 'https://example.com/image.jpg',
    'url'         => 'https://example.com/destination/',
    'subitems'    => array(
        array(
            'label' => 'Related link',
            'url'   => 'https://example.com/destination/#section',
        ),
    ),
)
```

### Blog dropdown

The Blog mega menu automatically queries up to four recent published posts.

Each card may display:

- Featured image.
- Title.
- Excerpt.
- Publish date.
- Read-more link.

The grid adapts to one, two, three, or four posts and does not reserve empty columns. A bundled placeholder is used when a post has no featured image.

### Do not hardcode the navigation HTML

Do not replace the WordPress menu with a static list in `header.php`. The menu must remain managed through WordPress and rendered through `wp_nav_menu()`.

---

## Front-page composition

`front-page.php` supports a true hybrid classic/block workflow:

1. When the assigned static front page contains stored content, the template runs the WordPress Loop and renders that content with `the_content()`. Gutenberg blocks, reusable patterns, embeds, pagination, and content filters therefore work normally.
2. When the assigned front page is empty, the theme uses the curated template-part composition as a safe default experience.

The empty-page fallback remains ordered as Hero, Brand statement, Featured work, All services, Service highlight, Process, Style pillars, Testimonials, Blog preview, and CTA banner.

Do not hardcode a second copy of editor-authored content into the fallback. Treat stored page content as authoritative whenever it exists. Wide and full-width blocks are implemented by constraining normal direct children of `.nytt01-entry-content` while allowing `.alignwide` and `.alignfull` children to use the wider layout tokens.

When changing the front page:

1. Test both a populated static front page and an empty static front page.
2. Test normal, wide, and full block alignment in the editor and frontend.
3. Run `npm run build` after SCSS changes.
4. Run `npm run release:verify` before release approval.

---

## `theme.json` design system

The theme uses:

```json
{
  "$schema": "https://schemas.wp.org/wp/7.0/theme.json",
  "version": 3
}
```

### `theme.json` owns

- Content width.
- Wide width.
- Editor color palette.
- Typography presets.
- Spacing presets.
- Border controls.
- Shadow presets.
- Default global text/background values.
- Default heading, link, button, image, and quote styles.
- Which editor design controls are available.

### SCSS owns

- Component layouts.
- Header and mega-menu layout.
- Responsive behavior.
- State classes.
- Interaction animation.
- Complex selectors.
- Third-party/plugin presentation.
- Browser-specific adjustments.

### Avoid duplicate design authorities

Do not define conflicting global values in:

- `theme.json`.
- `_variables.scss`.
- Customizer settings.
- Inline CSS.
- JavaScript.

Theme component aliases in `_variables.scss` must reference the WordPress-generated properties from `theme.json`; they must not duplicate the underlying literal values.

---

## SCSS architecture

SCSS source lives under:

```text
src/scss/
```

### Entry points

```text
src/scss/main.scss
src/scss/editor.scss
```

`main.scss` compiles to:

```text
assets/css/bundle.css
```

`editor.scss` compiles to:

```text
assets/css/editor.css
```

### Partial groups

#### `abstracts/`

Contains project design-token and reusable-source foundations.

#### `base/`

Contains low-specificity global element rules:

- Reset.
- Typography.
- Accessibility utilities.
- Form elements.
- Newsletter base presentation.

#### `layout/`

Contains large structural rules:

- Container.
- Grid.
- Header.
- Footer.
- Sections.

#### `components/`

Contains reusable UI components:

- Buttons.
- Cards.
- Forms.
- Mega menus.
- Badges.
- Accordions.
- Carousels.
- Portfolio filters.
- Before/after components.

#### `pages/`

Contains page-specific composition rules:

- Homepage.
- Contact.
- About.
- Services.
- Service detail.
- Work.
- Blog.
- Search.
- Error pages.
- Policy pages.

### SCSS editing rule

Never edit these generated files directly:

```text
assets/css/bundle.css
assets/css/editor.css
```

Any direct change will be overwritten by the next build.

---

## JavaScript architecture

JavaScript source lives under:

```text
src/js/
```

### Entry point

```text
src/js/main.js
```

Webpack compiles it to:

```text
assets/js/bundle.js
```

### Modules

#### `utilities/dom.js`

Provides DOM-ready utilities.

#### `components/navigation.js`

Controls the responsive primary navigation toggle.

#### `components/mega-menu.js`

Controls:

- Opening and closing mega menus.
- Single-open-menu enforcement.
- Outside-click dismissal.
- Focus-out dismissal.
- Escape-key handling.
- Trigger state through `aria-expanded`.
- Dynamic Services/About feature-panel updates.
- Related-link updates.
- Arrow-key movement between feature options.
- Reduced-motion behavior.
- Image preloading.

#### `components/accordion.js`

Controls accessible accordion expansion states.

### Progressive enhancement

Server-rendered PHP provides meaningful markup and links. JavaScript adds interaction rather than being used to generate the entire site shell.

### JavaScript editing rule

Never edit:

```text
assets/js/bundle.js
```

Edit the module under `src/js/`, then run a build.

---

## Webpack and build system

The project uses the WordPress-maintained `@wordpress/scripts` package, which is built on webpack. A project-level `webpack.config.js` extends the WordPress default configuration.

### Important directory distinction

There are three different concepts:

```text
/build                 Node helper scripts for this repository
webpack.config.js      Root webpack configuration
/assets                Compiled runtime output used by WordPress
```

The `/build` directory is **not** the compiled frontend output directory.

Compiled browser files go to `/assets` because the PHP theme enqueues them from that location.

### Webpack entry points

The root `webpack.config.js` defines:

```text
src/js/main.js       → assets/js/bundle.js
src/scss/main.scss   → assets/css/bundle.css
src/scss/editor.scss → assets/css/editor.css
```

### WordPress default webpack configuration

The config imports:

```js
@wordpress/scripts/config/webpack.config
```

This retains WordPress-maintained defaults for production/development modes, JavaScript transpilation, Sass handling, optimization, and asset dependency extraction.

### Empty-script removal

CSS entries can otherwise generate empty JavaScript files. The config uses:

```text
webpack-remove-empty-scripts
```

This removes those empty CSS-entry JavaScript artifacts after WordPress asset metadata is generated.

### Why `output.clean` is disabled

Webpack outputs into `/assets`, which also contains manually maintained images and icons. Global output cleaning could delete those runtime files.

Instead, `npm run clean` removes only known generated CSS, JavaScript, and metadata files.

### Build helper scripts

#### `build/clean.js`

Deletes only generated files:

```text
assets/css/bundle.css
assets/css/bundle-rtl.css
assets/css/bundle.asset.php
assets/css/editor.css
assets/css/editor-rtl.css
assets/css/editor.asset.php
assets/js/bundle.js
assets/js/bundle.asset.php
```

It does not delete images or icons.

#### `build/dev.js`

Starts a cross-platform production-mode webpack watcher for `npm run dev`. It sets `NODE_ENV` to production before loading the WordPress webpack defaults, emits minified watched assets, reports compilation warnings/errors, and closes cleanly on `Ctrl + C`.

#### `build/preflight.js`

Checks that the locked npm dependencies and local `wp-scripts` executable are installed. When they are missing, it stops with an explicit instruction to run `npm ci` from the theme root.

#### `build/validate.js`

Checks:

- Required files, including `build/dev.js` and `build/preflight.js`.
- Non-empty compiled assets.
- `theme.json` version and WordPress 7.0 schema.
- Version consistency between `package.json` and `style.css`.
- Required npm command definitions, the dependency preflight contract, and the direct webpack dependency used by `npm run dev`.
- WordPress/PHP metadata.
- 1200×900 PNG screenshot.
- Webpack asset metadata.
- Absence of theme-owned post type/taxonomy registration.
- Absence of unsupported root-level `403.php`.
- Absence of activation-time menu mutations.
- Presence of prefixed theme-owned pattern categories.

#### `build/package-theme.js`

Creates a production ZIP in:

```text
dist/nolan-young-theme-template-01.zip
```

It uses an explicit runtime allowlist so source/development files are excluded.

---

## NPM commands

Run commands from the theme root.

| Command | Purpose |
|---|---|
| `npm run start` | Fast unminified WordPress asset watcher |
| `npm run dev` | Minified production-mode watcher after an initial clean/lint pass |
| `npm run build` | Clean, lint, syntax-check, compile, and structurally validate source |
| `npm run check` | Run the build, zero-vulnerability npm audit, PHPCS/PHPCompatibility, and unit tests |
| `npm test` | Alias for the complete `npm run check` source gate |
| `npm run package` | Run all source gates, create a deterministic one-root ZIP, verify every packaged byte against source, and write SHA-256/release manifests |
| `npm run release:verify` | Package, extract that exact ZIP, start a clean WordPress 7.0/PHP 7.4 wp-env, run integration tests, Theme Check, desktop/mobile browser tests, and automated accessibility tests |

### Normal development

```bash
npm ci
composer install
npm run start
```

Stop the watcher before final verification.

### Source build and test gates

```bash
npm run build
npm test
```

`npm run build` validates maintained JavaScript, Node helpers, SCSS, current-PHP syntax, generated assets, release metadata, front-page block support, wide/full alignment rules, accessibility regressions, and architecture boundaries.

`npm test` additionally enforces:

- `npm audit` with zero known vulnerabilities.
- WordPress Coding Standards and WordPress documentation rules.
- PHPCompatibilityWP against PHP 7.4 and newer.
- Source-level PHPUnit regression tests.

### Create the production ZIP

```bash
npm run package
```

Output:

```text
dist/nolan-young-theme-template-01.zip
dist/nolan-young-theme-template-01.zip.sha256
dist/release-manifest.json
```

The package builder uses a sorted runtime allowlist and fixed archive timestamps. The parity verifier rejects missing, extra, renamed, or byte-different files and requires exactly one top-level `nolan-young-theme-template-01/` directory.

### Verify the exact packaged ZIP in WordPress

Docker must be running, and Playwright Chromium must be installed once:

```bash
npx playwright install chromium
npm run release:verify
```

The release verifier destroys any previous wp-env state, extracts the exact generated ZIP, mounts that extracted package as the installed theme, activates it in WordPress 7.0 running PHP 7.4, creates deterministic test content, and runs:

- WordPress integration tests.
- Theme Check through WP-CLI.
- Desktop Chromium tests.
- Mobile Chromium tests.
- Axe serious/critical accessibility checks.
- Front-page normal/wide/full alignment checks.
- Contextual archive-link checks.

The environment is stopped and destroyed after the run. Source mounting is kept separate from the installed packaged theme so browser and Theme Check results apply to the exact archive contents rather than an un-packaged checkout.

---

## Generated asset metadata

The WordPress webpack dependency-extraction tooling generates `*.asset.php` files adjacent to built assets.

Example shape:

```php
<?php
return array(
    'dependencies' => array(),
    'version'      => 'content-hash',
);
```

These files allow PHP to enqueue the exact dependencies and a build-derived cache version.

Current metadata files:

```text
assets/css/bundle.asset.php
assets/css/editor.asset.php
assets/js/bundle.asset.php
```

Do not manually edit them. They are regenerated by webpack.

---

## WordPress asset enqueueing

Frontend assets are loaded in `inc/enqueue.php` through:

```php
wp_enqueue_style()
wp_enqueue_script()
```

The implementation:

1. Loads the applicable `*.asset.php` metadata.
2. Validates the dependency array.
3. Uses the generated version.
4. Falls back to `filemtime()` or the theme version only when metadata is unavailable.
5. Loads JavaScript in the footer with the `defer` strategy.
6. Loads WordPress `comment-reply` only when threaded comments require it.

Do not hardcode asset URLs in templates.

Use:

```php
get_theme_file_uri()
get_theme_file_path()
```

rather than concatenating theme paths manually.

---

## Editor styles

The theme enables editor styles in `inc/setup.php`:

```php
add_theme_support( 'editor-styles' );
add_editor_style( 'assets/css/editor.css' );
```

The editor stylesheet is intentionally separate from the full frontend bundle. This prevents frontend-only behavior such as sticky headers, navigation overlays, and fixed widgets from interfering with editor controls.

When adding typography or reusable content components, evaluate whether corresponding editor styles are required.

---

## Block patterns and block styles

### Patterns

Pattern files live in:

```text
patterns/
```

Current patterns include:

- Hero.
- Featured work.
- Services grid.
- Testimonials.
- Call to action.

WordPress automatically discovers correctly headed pattern files in this directory.

Pattern rules:

- Keep output translatable.
- Escape dynamic PHP values.
- Use valid block markup.
- Reference theme assets with WordPress functions.
- Do not process requests.

### Block styles

The theme registers custom styles for:

```text
core/group  → nytt01-card
core/button → nytt01-outline
```

The registration lives in `inc/block-styles.php`; presentation lives in source SCSS.

---

## Customizer settings

The theme registers a **Front Page Presentation** section for:

- Hero eyebrow.
- Hero heading.
- Hero description.

These are presentation-oriented theme modifications. They are sanitized with `sanitize_text_field()`.

Do not use the Customizer module to store:

- API keys.
- Submission records.
- Product data.
- Service records.
- Authentication settings.
- Business-critical configuration that must survive a theme switch.

---

## Internationalization

The text domain is:

```text
nolan-young-theme-template-01
```

It must match the theme slug and remain consistent in every translation call.

Translation files live under:

```text
languages/
```

The POT template is:

```text
languages/nolan-young-theme-template-01.pot
```

### Translation functions

Use the correct function for the output context:

```php
__( 'Text', 'nolan-young-theme-template-01' );
_e( 'Text', 'nolan-young-theme-template-01' );
esc_html__( 'Text', 'nolan-young-theme-template-01' );
esc_html_e( 'Text', 'nolan-young-theme-template-01' );
esc_attr__( 'Text', 'nolan-young-theme-template-01' );
esc_attr_e( 'Text', 'nolan-young-theme-template-01' );
```

Add translator comments immediately before formatted translation strings.

### POT regeneration

With WP-CLI and the i18n command available:

```bash
wp i18n make-pot . languages/nolan-young-theme-template-01.pot \
  --domain=nolan-young-theme-template-01 \
  --exclude=node_modules,vendor,dist,tests
```

Review the generated file before committing it.

---

## Security requirements

### Escape late

Escape dynamic values at output:

```php
echo esc_html( $text );
echo esc_attr( $attribute );
echo esc_url( $url );
echo wp_kses_post( $trusted_formatted_content );
```

### Sanitize input

Use context-appropriate sanitization for theme settings:

```php
sanitize_text_field()
sanitize_email()
sanitize_key()
absint()
esc_url_raw()
```

### No request processing in the theme

The theme must not directly process:

```text
$_POST
$_GET
$_REQUEST
uploaded files
newsletter subscriptions
contact submissions
```

Those responsibilities belong in the companion plugin.

### No secrets

Never commit:

- Passwords.
- API keys.
- Access tokens.
- SMTP credentials.
- Private signing keys.
- Database credentials.
- `.env` files.

### WordPress APIs first

Use WordPress APIs instead of direct database access whenever possible. Any unavoidable SQL must use prepared statements in the plugin layer, not presentation templates.

---

## Accessibility requirements

WCAG 2.2 Level AA is the internal release target.

### Required behaviors

- Keyboard-accessible navigation.
- Visible focus indication.
- Skip-to-content link.
- Logical heading hierarchy.
- Semantic landmarks.
- Properly labeled form fields.
- Understandable validation errors.
- Accessible menu trigger state through `aria-expanded` and `aria-controls`.
- Escape-key dismissal for open overlays/dropdowns.
- Focus restoration after dismissal.
- No hover-only functionality.
- Reduced-motion support.
- Sufficient text and control contrast.
- No keyboard traps.

### Mega-menu keyboard behavior

- `Enter` or `Space`: activate the focused button through native button behavior.
- `ArrowDown` on a top-level trigger: open and move focus into the panel.
- Arrow keys in featured options: move between options.
- `Home`: move to the first option.
- `End`: move to the last option.
- `Escape`: close and return focus to the trigger.

### Accessibility testing is manual and automated

Automated checks are useful but cannot prove full accessibility. Every release needs manual keyboard and screen-reader review.

---

## PHP coding standards

Development configuration lives in `composer.json`, `composer.lock`, `phpcs.xml.dist`, `phpunit.xml.dist`, and `phpunit.integration.xml.dist`.

Install the exact PHP toolchain:

```bash
composer install
```

The Composer platform is locked to PHP 7.4.33 so dependency resolution cannot silently select packages that violate the declared minimum. The PHPCS ruleset includes WordPress, WordPress Extra, WordPress Docs, and PHPCompatibilityWP with `testVersion` set to `7.4-`.

```bash
composer lint:php
composer test:unit
composer check
```

`composer check` runs PHPCS/PHPCompatibility and source-level PHPUnit. `composer fix:php` may apply safe mechanical fixes, but every change must be reviewed.

### Unit tests

`tests/unit/` runs without WordPress and protects release-critical source contracts:

- Front-page Loop and `the_content()` behavior.
- Wide/full alignment architecture.
- Absence of activation-time menu persistence.
- Synchronized non-placeholder release metadata.
- Contextual read-more link text.

### WordPress integration tests

`tests/integration/` runs against the official WordPress PHPUnit environment exposed by wp-env. It verifies:

- Required runtime files and generated assets.
- Theme support registration.
- Navigation locations.
- Frontend enqueue handles.
- Static front-page selection and content-filter behavior.

Run these tests through the exact-package environment:

```bash
npm run package
npm run prepare:release-env
npm run env:start
npm run env:setup
npm run test:integration
npm run env:stop
npm run env:destroy
```

### Browser, accessibility, responsive, and Theme Check coverage

`tests/e2e/theme.spec.js` runs in desktop and mobile Chromium. It checks stored front-page content, normal/wide/full geometry, horizontal overflow, contextual archive links, PHP-fatal output, and serious/critical Axe violations. `npm run test:theme-check` runs the official Theme Check plugin command against the packaged theme.

These automated checks supplement, but do not eliminate, manual keyboard, screen-reader, browser, visual-regression, content-edge-case, and production-host testing.

### Required manual matrix

Before release, manually review:

- Current Chrome, Firefox, Safari, and Edge.
- iOS Safari and Android Chrome.
- Keyboard-only navigation and visible focus.
- VoiceOver or NVDA landmark/link navigation.
- Reduced-motion and high-zoom behavior.
- Front page populated and empty.
- Posts index, singular pages/posts, archives, search, 404, comments, pagination, and privacy policy.
- Companion plugin active and inactive.
- Long titles, missing images, empty menus, and one-to-four mega-menu posts.

---

## Local debugging

Enable development debugging in the local or staging `wp-config.php`:

```php
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', true );
define( 'SCRIPT_DEBUG', true );
```

Do not enable visible debugging on production.

Review:

```text
wp-content/debug.log
```

Before release, submit forms, exercise navigation, open archives, and review the log for:

- Notices.
- Warnings.
- Deprecated calls.
- Fatal errors.
- Translation warnings.
- Undefined indexes or variables.

The form-processing incident fixed in `nolan-young-core` 1.0.1 is an example of why submission-path testing under `WP_DEBUG` is mandatory.

---

## Release and packaging workflow

1. Start from a clean source checkout and inspect `git status`.
2. Install both lockfiles with `npm ci` and `composer install`.
3. Keep the version synchronized in `style.css`, `package.json`, `package-lock.json`, `readme.txt`, translation metadata, and `CHANGELOG.md`.
4. Stop all asset watchers.
5. Run `npm test`.
6. Run `npm run package`.
7. Inspect `dist/release-manifest.json` and preserve the generated SHA-256 file with the distributed ZIP.
8. With Docker available, run `npm run release:verify`. This installs and tests the exact extracted package in clean WordPress 7.0/PHP 7.4 state.
9. Perform the manual cross-browser, keyboard, screen-reader, responsive, plugin-integration, and host-staging matrix.
10. Approve only the exact ZIP whose checksum and staging result were recorded.

A successful source build is not enough. A release is approved only when source checks, deterministic package parity, exact-ZIP WordPress installation, automated tests, and manual staging checks all refer to the same artifact.

---

## Production ZIP contents

The packaging script includes runtime files only.

### Included

- Root PHP templates.
- `style.css`.
- `functions.php`.
- `theme.json`.
- `screenshot.png`.
- `README.md`.
- `CHANGELOG.md`.
- `LICENSE.txt`.
- `/inc`.
- `/template-parts`.
- `/page-templates`.
- `/patterns`.
- `/languages`.
- Compiled `/assets`.

### Excluded

- `node_modules/`.
- `vendor/`.
- `.git/`.
- `src/`.
- `build/`.
- `tests/`.
- `docs/`.
- `webpack.config.js`.
- `package.json`.
- `package-lock.json`.
- `composer.json`.
- `phpcs.xml.dist`.
- `dist/`.
- IDE configuration.
- Debug logs.
- Environment files.

### Why source files are excluded

The installed site needs compiled browser assets, not the development toolchain. Excluding development files produces a smaller, clearer deployment artifact and avoids shipping unnecessary dependencies or configuration.

---

## Common development workflows

### Change a PHP template only

```bash
# Edit the PHP template.
php -l path/to/file.php
composer lint:php
npm run validate
```

A CSS/JS rebuild is not required unless source assets also changed.

### Change SCSS

For fast, readable development output:

```bash
npm run start
# Edit src/scss/... files.
# Stop watch mode with Ctrl+C.
npm run build
```

For minified production-style output during local iteration, use `npm run dev` instead of `npm run start`. Always stop the watcher and run `npm run build` last.

### Change JavaScript

```bash
npm run start
# Or use: npm run dev
# Edit src/js/... files.
# Test keyboard and pointer behavior.
# Stop watch mode with Ctrl+C.
npm run build
```

Use `npm run start` for easier debugging and `npm run dev` when you specifically need minified watched output. The final production build remains mandatory in both cases.

### Change the mega-menu data

For reusable/site-specific content, use the documented PHP filters in a companion/site plugin. If changing theme defaults:

1. Edit `inc/navigation.php`.
2. Keep all labels translatable.
3. Sanitize/escape URLs and output.
4. Test one to four Blog posts.
5. Test keyboard behavior.
6. Run PHP and npm checks.

### Add a SCSS component

1. Create `src/scss/components/_component-name.scss`.
2. Import it from `src/scss/main.scss` in the correct layer/order.
3. Add editor styles only if content authors need them in the editor.
4. Stop any watcher and run `npm run build`.

### Add a JavaScript component

1. Create a focused module under `src/js/components/`.
2. Export one initialization function.
3. Import it from `src/js/main.js`.
4. Initialize it inside the DOM-ready callback.
5. Ensure the page remains usable if JavaScript fails.
6. Stop any watcher and run `npm run build`.

### Add a page template

1. Create the file under `/page-templates`.
2. Add a valid `Template Name` header.
3. Use standard `get_header()`, Loop, template-part, and `get_footer()` patterns.
4. Do not process requests.
5. Add corresponding source SCSS only when necessary.
6. Document it here.

### Add a custom post type template

The plugin must register the post type. The theme may add recognized templates such as:

```text
single-{post-type}.php
archive-{post-type}.php
taxonomy-{taxonomy}.php
```

Do not register the content type in the theme.

---

## Troubleshooting

### `npm` is not recognized

Install a supported Node.js release, close/reopen the terminal, then verify:

```bash
node --version
npm --version
```

### `npm ci` says the lockfile is out of sync

The dependency manifest was changed without updating the lockfile.

On the branch that intentionally changes dependencies:

```bash
npm install
```

Review and commit both `package.json` and `package-lock.json`.

Do not casually delete the lockfile.

### The build cannot resolve `@wordpress/scripts`

Dependencies are missing or the command is being run outside the theme root.

```bash
npm ci
```

Then verify that the current directory contains `package.json`.

### Styles changed in source but not on the site

1. Confirm the edit was under `src/scss`, not `assets/css`.
2. Run `npm run build`.
3. Confirm `assets/css/bundle.css` changed.
4. Clear WordPress/host/CDN/browser caches.
5. Inspect the enqueued stylesheet URL/version.

### JavaScript changed in source but behavior did not change

1. Run `npm run build`.
2. Confirm `assets/js/bundle.js` changed.
3. Clear caches.
4. Check the browser console.
5. Verify markup still contains the required `data-nytt01-*` attributes.

### The mega menu does not attach to a renamed menu item

Add the explicit CSS class:

```text
nytt01-mega-services
nytt01-mega-about
nytt01-mega-blog
```

### The Blog mega menu is empty

Confirm that published Posts exist. Drafts, private posts, and custom post types do not populate the latest-post cards.

### The Blog card has a placeholder image

Assign a featured image to the post.

### The Contact button is incorrect

The header CTA currently targets:

```text
/contact/
```

Create that page or deliberately update the URL in the header implementation.

### Editor styles are missing

1. Run `npm run build`.
2. Confirm `assets/css/editor.css` exists.
3. Confirm `add_theme_support( 'editor-styles' )` runs before `add_editor_style()`.
4. Clear the editor/browser cache.

### `npm run package` fails validation

Run the individual stages:

```bash
npm run lint:js
npm run lint:node
npm run lint:css
npm run build
```

Fix the first failing stage rather than bypassing it.

### A form causes a fatal error

Form processing belongs to `nolan-young-core`, not this theme.

1. Confirm the plugin version is current.
2. Enable local `WP_DEBUG`.
3. Review `wp-content/debug.log`.
4. Reproduce with a mail logger enabled.
5. Test the plugin submission handler directly.

Do not move the form handler into the theme as a workaround.

---

## Non-negotiable maintenance rules

1. **The theme owns presentation only.**
2. **Persistent/business functionality remains in plugins.**
3. **`functions.php` remains a bootstrap file.**
4. **Use the WordPress template hierarchy rather than invented root templates.**
5. **Do not add a root-level `403.php`.**
6. **Do not register custom post types or taxonomies in the theme.**
7. **Do not process forms in the theme.**
8. **Do not hardcode the primary menu in `header.php`.**
9. **Keep the Primary Navigation WordPress-managed.**
10. **Edit SCSS and JavaScript only under `/src`.**
11. **Never manually patch generated files under `/assets/css` or `/assets/js`.**
12. **Use `theme.json` as the WordPress design-system authority.**
13. **Load assets through WordPress enqueue APIs.**
14. **Use generated asset metadata for dependencies and versions.**
15. **Prefix public identifiers with `nytt01_` or `nytt01-` as appropriate.**
16. **Use the exact text domain `nolan-young-theme-template-01`.**
17. **Escape dynamic output at the point of output.**
18. **Sanitize theme-controlled input.**
19. **Never commit credentials or secrets.**
20. **Preserve keyboard navigation and reduced-motion behavior.**
21. **Keep the screenshot exactly 1200×900.**
22. **Keep `style.css`, `package.json`, and `CHANGELOG.md` versions synchronized.**
23. **Stop every watcher and run `npm run build` as the final asset command before review or packaging.**
24. **Run PHP_CodeSniffer before release.**
25. **Test with `WP_DEBUG` on local/staging.**
26. **Do not create or assign database content during theme activation.**
27. **Prefix all theme-owned pattern categories and public identifiers.**
26. **Test the installable ZIP on a clean WordPress site.**
27. **Ship exactly one top-level theme directory in the ZIP.**
28. **Update this README whenever architecture or commands change.**

---

## Official WordPress references

The architecture and practices in this project are based on the official WordPress developer documentation:

- Theme Handbook: https://developer.wordpress.org/themes/
- Classic themes: https://developer.wordpress.org/themes/classic-themes/
- Theme structure: https://developer.wordpress.org/themes/core-concepts/theme-structure/
- Main stylesheet: https://developer.wordpress.org/themes/core-concepts/main-stylesheet/
- Custom functionality: https://developer.wordpress.org/themes/core-concepts/custom-functionality/
- Including assets: https://developer.wordpress.org/themes/core-concepts/including-assets/
- Build process: https://developer.wordpress.org/themes/advanced-topics/build-process/
- `@wordpress/scripts`: https://developer.wordpress.org/block-editor/reference-guides/packages/packages-scripts/
- `theme.json`: https://developer.wordpress.org/themes/global-settings-and-styles/introduction-to-theme-json/
- Patterns: https://developer.wordpress.org/themes/patterns/
- Internationalization: https://developer.wordpress.org/themes/advanced-topics/internationalization/
- Security: https://developer.wordpress.org/themes/advanced-topics/security/
- Accessibility: https://developer.wordpress.org/themes/functionality/accessibility/
- Debugging: https://developer.wordpress.org/themes/advanced-topics/debugging/
- Testing: https://developer.wordpress.org/themes/releasing-your-theme/testing/
- WordPress Coding Standards: https://developer.wordpress.org/coding-standards/wordpress-coding-standards/
- PHP Coding Standards: https://developer.wordpress.org/coding-standards/wordpress-coding-standards/php/
- JavaScript Coding Standards: https://developer.wordpress.org/coding-standards/wordpress-coding-standards/javascript/
- CSS Coding Standards: https://developer.wordpress.org/coding-standards/wordpress-coding-standards/css/

---

## Final release principle

A successful build is not the same as a production-ready release.

A production release requires all of the following:

```text
source review
+ WordPress standards review
+ clean dependency installation
+ linting
+ production build
+ structural validation
+ PHP standards checks
+ WordPress runtime testing
+ accessibility testing
+ clean ZIP installation testing
```

If any part of that chain fails, the release is not approved.
