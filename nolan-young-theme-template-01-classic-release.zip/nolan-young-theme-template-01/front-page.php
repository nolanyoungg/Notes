<?php
/**
 * Front-page template.
 *
 * Stored block content is authoritative when the assigned front page contains
 * content. The curated template-part composition remains a safe visual
 * fallback for a new or intentionally empty front page.
 *
 * @package NolanYoungThemeTemplate01
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="primary" class="nytt01-site-main">
	<?php
	while ( have_posts() ) :
		the_post();

		$nytt01_front_page_content = trim( (string) get_post_field( 'post_content', get_the_ID() ) );

		if ( '' !== $nytt01_front_page_content ) :
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'nytt01-entry nytt01-front-page-entry' ); ?>>
				<div class="nytt01-entry-content">
					<?php
					the_content();
					wp_link_pages(
						array(
							'before' => '<nav class="nytt01-page-links" aria-label="' . esc_attr__( 'Page', 'nolan-young-theme-template-01' ) . '">',
							'after'  => '</nav>',
						)
					);
					?>
				</div>
			</article>
			<?php
		else :
			get_template_part( 'template-parts/global/content', 'hero' );
			get_template_part( 'template-parts/global/content', 'brand-statement' );
			get_template_part( 'template-parts/front-page/content', 'featured-work' );
			get_template_part( 'template-parts/front-page/content', 'all-services' );
			get_template_part( 'template-parts/front-page/content', 'service-highlight' );
			get_template_part( 'template-parts/front-page/content', 'process' );
			get_template_part( 'template-parts/front-page/content', 'style-pillars' );
			get_template_part( 'template-parts/front-page/content', 'testimonials' );
			get_template_part( 'template-parts/front-page/content', 'blog-preview' );
			get_template_part( 'template-parts/global/content', 'cta-banner' );
		endif;
	endwhile;
	?>
</main>
<?php
get_footer();
