=== Nolan Young Theme Template 01 ===
Contributors: nolanyoungg
Requires at least: 7.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.2.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: accessibility-ready, blog, custom-logo, custom-menu, featured-images, full-width-template, translation-ready, wide-blocks

A production-oriented classic WordPress theme with modern theme.json, block-editor styles, reusable block patterns, and accessible templates.

== Description ==

Nolan Young Theme Template 01 is a classic PHP theme with modern block-editor compatibility. It uses the WordPress template hierarchy for frontend rendering while theme.json, editor styles, block styles, and patterns support Gutenberg authoring.

The theme owns presentation. Persistent application functionality, custom content registration, forms, newsletter processing, access rules, and privacy integrations belong in the companion plugin.

== Installation ==

1. Upload the generated nolan-young-theme-template-01.zip through Appearance > Themes > Add New > Upload Theme.
2. Activate the theme.
3. Assign a Primary Navigation menu.
4. Configure a static front page and Posts page when required.
5. Review the Customizer and Site Identity settings.

== Frequently Asked Questions ==

= Is this a block theme? =

No. It is a classic theme that uses modern block-editor features. PHP template files remain authoritative for request rendering.

= Can the front page use blocks? =

Yes. Stored block content on the assigned static front page is rendered when present. The theme's curated template-part composition is used only when that page is empty.

= Does the theme create menus on activation? =

No. It registers menu locations and provides a non-persistent fallback until an administrator assigns a menu.

== Changelog ==

= 1.2.3 =
* Added authoritative front-page block rendering with a safe empty-page fallback.
* Corrected wide and full-width block layout behavior.
* Improved contrast and contextualized repetitive read-more links.
* Added deterministic package parity, PHP standards, compatibility, integration, Theme Check, browser, and accessibility gates.
