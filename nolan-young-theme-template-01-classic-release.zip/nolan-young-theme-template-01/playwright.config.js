'use strict';

const { defineConfig, devices } = require( '@playwright/test' );

module.exports = defineConfig( {
	testDir: './tests/e2e',
	fullyParallel: false,
	forbidOnly: Boolean( process.env.CI ),
	retries: process.env.CI ? 2 : 0,
	reporter: process.env.CI
		? [ [ 'line' ], [ 'html', { open: 'never' } ] ]
		: 'line',
	use: {
		baseURL: process.env.WP_BASE_URL || 'http://localhost:8888',
		trace: 'on-first-retry',
	},
	projects: [
		{
			name: 'desktop-chromium',
			use: { ...devices[ 'Desktop Chrome' ] },
		},
		{
			name: 'mobile-chromium',
			use: { ...devices[ 'Pixel 7' ] },
		},
	],
	outputDir: 'test-results/playwright',
} );
