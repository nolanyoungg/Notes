<?php
/**
 * Title: Testimonial
 * Slug: nolan-young-theme-template-01/testimonial
 * Categories: nytt01-testimonials, text
 * Keywords: testimonial, quote, review
 * Inserter: true
 *
 * @package NolanYoungThemeTemplate01
 */

?>
<!-- wp:quote {"align":"wide"} --><blockquote class="wp-block-quote alignwide"><p><?php esc_html_e( 'The process was structured, transparent, and focused on measurable results.', 'nolan-young-theme-template-01' ); ?></p><cite><?php esc_html_e( 'Client name, Organization', 'nolan-young-theme-template-01' ); ?></cite></blockquote><!-- /wp:quote -->