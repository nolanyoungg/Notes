<?php
/**
 * Service archive and service-category taxonomy template.
 *
 * @package NolanYoungThemeTemplate01
 */

defined( 'ABSPATH' ) || exit;

$nytt01_is_service_taxonomy = is_tax( 'ny_service_category' );
$nytt01_archive_title       = $nytt01_is_service_taxonomy
	? single_term_title( '', false )
	: post_type_archive_title( '', false );
$nytt01_archive_description = $nytt01_is_service_taxonomy
	? term_description()
	: esc_html__( 'Explore the services available through this site.', 'nolan-young-theme-template-01' );

get_header();
?>
<main id="primary" class="nytt01-site-main nytt01-container nytt01-content-area">
	<header class="nytt01-page-header">
		<h1><?php echo esc_html( $nytt01_archive_title ); ?></h1>
		<?php if ( $nytt01_archive_description ) : ?>
			<?php if ( $nytt01_is_service_taxonomy ) : ?>
				<div class="nytt01-archive-description">
					<?php echo wp_kses_post( $nytt01_archive_description ); ?>
				</div>
			<?php else : ?>
				<p><?php echo esc_html( $nytt01_archive_description ); ?></p>
			<?php endif; ?>
		<?php endif; ?>
	</header>
	<?php if ( have_posts() ) : ?>
		<div class="nytt01-card-grid">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content/content', 'search' );
			endwhile;
			?>
		</div>
		<?php nytt01_posts_pagination(); ?>
	<?php else : ?>
		<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
	<?php endif; ?>
</main>
<?php
get_footer();
