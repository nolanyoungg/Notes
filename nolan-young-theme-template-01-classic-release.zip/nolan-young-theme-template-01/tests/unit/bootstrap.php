<?php
/**
 * Source-level PHPUnit bootstrap.
 *
 * @package NolanYoungThemeTemplate01
 */

define( 'NYTT01_TEST_ROOT', dirname( __DIR__, 2 ) );
