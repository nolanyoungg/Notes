<?php
/**
 * Source architecture regression tests.
 *
 * @package NolanYoungThemeTemplate01
 */

use PHPUnit\Framework\TestCase;

/**
 * Protect release-critical source architecture.
 */
final class Source_Architecture_Test extends TestCase {
	/**
	 * Confirm that block content is rendered by the front-page controller.
	 *
	 * @return void
	 */
	public function test_front_page_renders_stored_content() {
		$contents = file_get_contents( NYTT01_TEST_ROOT . '/front-page.php' );

		$this->assertStringContainsString( 'while ( have_posts() )', $contents );
		$this->assertStringContainsString( 'the_content();', $contents );
		$this->assertStringContainsString( "get_post_field( 'post_content'", $contents );
	}

	/**
	 * Confirm that wide and full blocks can escape the content measure.
	 *
	 * @return void
	 */
	public function test_block_alignment_layout_is_present() {
		$contents = file_get_contents( NYTT01_TEST_ROOT . '/src/scss/layout/_container.scss' );

		$this->assertStringContainsString( '.nytt01-entry-content > .alignwide', $contents );
		$this->assertStringContainsString( '.nytt01-entry-content > .alignfull', $contents );
		$this->assertStringContainsString( 'width: 100vw;', $contents );
		$this->assertStringContainsString( 'margin-inline: calc(50% - 50vw);', $contents );
	}

	/**
	 * Confirm that theme activation does not mutate persistent menu data.
	 *
	 * @return void
	 */
	public function test_runtime_php_has_no_activation_time_menu_mutation() {
		$iterator            = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator(
				NYTT01_TEST_ROOT,
				FilesystemIterator::SKIP_DOTS
			)
		);
		$prohibited_patterns = array(
			'/\bwp_create_nav_menu\s*\(/',
			'/\bwp_update_nav_menu_item\s*\(/',
			'/add_action\s*\(\s*[\'\"]after_switch_theme[\'\"]/',
		);

		foreach ( $iterator as $file ) {
			$path          = $file->getPathname();
			$relative_path = str_replace( '\\', '/', substr( $path, strlen( NYTT01_TEST_ROOT ) + 1 ) );

			if ( ! $file->isFile() || 'php' !== $file->getExtension() ) {
				continue;
			}

			if ( preg_match( '#^(tests|vendor)/#', $relative_path ) ) {
				continue;
			}

			$contents = file_get_contents( $path );

			foreach ( $prohibited_patterns as $pattern ) {
				$this->assertDoesNotMatchRegularExpression( $pattern, $contents, $relative_path );
			}
		}
	}

	/**
	 * Confirm release metadata remains synchronized and non-placeholder.
	 *
	 * @return void
	 */
	public function test_release_metadata_is_synchronized() {
		$package = json_decode(
			file_get_contents( NYTT01_TEST_ROOT . '/package.json' ),
			true,
			512,
			JSON_THROW_ON_ERROR
		);
		$style   = file_get_contents( NYTT01_TEST_ROOT . '/style.css' );

		$this->assertStringContainsString( 'Version: ' . $package['version'], $style );
		$this->assertStringNotContainsString( 'example.com', $style );
		$this->assertStringContainsString( 'Requires PHP: 7.4', $style );
	}

	/**
	 * Confirm generic card links expose contextual titles.
	 *
	 * @return void
	 */
	public function test_read_more_links_include_context() {
		$contents = file_get_contents(
			NYTT01_TEST_ROOT . '/template-parts/content/content-search.php'
		);

		$this->assertStringContainsString( 'screen-reader-text', $contents );
		$this->assertStringContainsString( ' about %s', $contents );
	}
}
