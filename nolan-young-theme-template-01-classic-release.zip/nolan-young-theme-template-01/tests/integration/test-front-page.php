<?php
/**
 * Front-page integration tests.
 *
 * @package NolanYoungThemeTemplate01
 */

/**
 * Validate WordPress front-page selection and block rendering support.
 */
class NYTT01_Front_Page_Test extends WP_UnitTestCase {
	/**
	 * Confirm the static front-page controller contains the WordPress loop.
	 *
	 * @return void
	 */
	public function test_front_page_template_is_selected_for_static_front_page() {
		$page_id = self::factory()->post->create(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => 'Automated Front Page',
				'post_content' => '<!-- wp:paragraph --><p>Rendered block content.</p><!-- /wp:paragraph -->',
			)
		);

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $page_id );
		$this->go_to( home_url( '/' ) );

		$this->assertTrue( is_front_page() );
		$this->assertSame( get_theme_file_path( '/front-page.php' ), get_query_template( 'front_page' ) );
		$this->assertStringContainsString(
			'Rendered block content.',
			apply_filters( 'the_content', get_post_field( 'post_content', $page_id ) )
		);
	}
}
