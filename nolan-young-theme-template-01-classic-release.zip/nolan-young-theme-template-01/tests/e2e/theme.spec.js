'use strict';

const AxeBuilder = require( '@axe-core/playwright' ).default;
const { expect, test } = require( '@playwright/test' );

test( 'stored front-page blocks render without horizontal overflow', async ( {
	page,
}, testInfo ) => {
	await page.goto( '/' );

	await expect( page.locator( '.nytt01-e2e-standard' ) ).toContainText(
		'Automated front-page block content.'
	);
	await expect( page.locator( 'body' ) ).not.toContainText( 'Fatal error' );

	const dimensions = await page.evaluate( () => {
		const standard = document.querySelector( '.nytt01-e2e-standard' );
		const wide = document.querySelector( '.nytt01-e2e-wide' );
		const full = document.querySelector( '.nytt01-e2e-full' );

		if ( ! standard || ! wide || ! full ) {
			throw new Error( 'Expected alignment fixtures were not rendered.' );
		}

		return {
			documentWidth: document.documentElement.scrollWidth,
			fullWidth: full.getBoundingClientRect().width,
			standardWidth: standard.getBoundingClientRect().width,
			viewportWidth: window.innerWidth,
			wideWidth: wide.getBoundingClientRect().width,
		};
	} );

	if ( 'desktop-chromium' === testInfo.project.name ) {
		expect( dimensions.wideWidth ).toBeGreaterThan(
			dimensions.standardWidth
		);
		expect( dimensions.fullWidth ).toBeGreaterThan( dimensions.wideWidth );
	} else {
		expect( dimensions.wideWidth ).toBeLessThanOrEqual(
			dimensions.viewportWidth
		);
	}

	expect( dimensions.fullWidth ).toBeGreaterThanOrEqual(
		dimensions.viewportWidth - 2
	);
	expect( dimensions.documentWidth ).toBeLessThanOrEqual(
		dimensions.viewportWidth + 1
	);
} );

test( 'primary pages have no serious or critical automated accessibility violations', async ( {
	page,
} ) => {
	for ( const path of [ '/', '/blog/' ] ) {
		await page.goto( path );
		const results = await new AxeBuilder( { page } ).analyze();
		const blockingViolations = results.violations.filter( ( violation ) =>
			[ 'serious', 'critical' ].includes( violation.impact )
		);

		expect(
			blockingViolations,
			`Accessibility violations at ${ path }`
		).toEqual( [] );
	}
} );

test( 'archive read-more links expose the destination title', async ( {
	page,
} ) => {
	await page.goto( '/blog/' );
	const links = page.locator( '.nytt01-card .nytt01-text-link' );

	await expect( links ).toHaveCount( 2 );
	await expect( links.nth( 0 ) ).toContainText(
		/Read more about Accessible Link Test/
	);
	await expect( links.nth( 1 ) ).toContainText(
		/Read more about Accessible Link Test/
	);
} );
