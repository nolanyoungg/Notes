<?php
/**
 * Create deterministic browser-test content inside wp-env.
 *
 * This file is executed with `wp eval-file` and is not shipped in the
 * production theme package.
 *
 * @package NolanYoungThemeTemplate01
 */

$front_page_content = <<<'BLOCKS'
<!-- wp:paragraph {"className":"nytt01-e2e-standard"} -->
<p class="nytt01-e2e-standard">Automated front-page block content.</p>
<!-- /wp:paragraph -->
<!-- wp:group {"align":"wide","className":"nytt01-e2e-wide"} -->
<div class="wp-block-group alignwide nytt01-e2e-wide"><!-- wp:paragraph -->
<p>Automated wide block.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"align":"full","className":"nytt01-e2e-full"} -->
<div class="wp-block-group alignfull nytt01-e2e-full"><!-- wp:paragraph -->
<p>Automated full-width block.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
BLOCKS;

$front_page    = get_page_by_path( 'automated-front-page' );
$front_page_id = wp_insert_post(
	array(
		'ID'           => $front_page ? $front_page->ID : 0,
		'post_content' => $front_page_content,
		'post_name'    => 'automated-front-page',
		'post_status'  => 'publish',
		'post_title'   => 'Automated Front Page',
		'post_type'    => 'page',
	),
	true
);

if ( is_wp_error( $front_page_id ) ) {
	throw new RuntimeException( esc_html( $front_page_id->get_error_message() ) );
}

$posts_page    = get_page_by_path( 'blog' );
$posts_page_id = wp_insert_post(
	array(
		'ID'          => $posts_page ? $posts_page->ID : 0,
		'post_name'   => 'blog',
		'post_status' => 'publish',
		'post_title'  => 'Blog',
		'post_type'   => 'page',
	),
	true
);

if ( is_wp_error( $posts_page_id ) ) {
	throw new RuntimeException( esc_html( $posts_page_id->get_error_message() ) );
}

$existing_test_posts = get_posts(
	array(
		'fields'           => 'ids',
		'posts_per_page'   => -1,
		'post_status'      => 'any',
		'post_type'        => 'post',
		'suppress_filters' => false,
	)
);

foreach ( $existing_test_posts as $existing_test_post_id ) {
	wp_delete_post( $existing_test_post_id, true );
}

foreach ( array( 'Accessible Link Test One', 'Accessible Link Test Two' ) as $test_post_title ) {
	$test_post_id = wp_insert_post(
		array(
			'post_content' => '<p>Automated archive-card content.</p>',
			'post_status'  => 'publish',
			'post_title'   => $test_post_title,
			'post_type'    => 'post',
		),
		true
	);

	if ( is_wp_error( $test_post_id ) ) {
		throw new RuntimeException( esc_html( $test_post_id->get_error_message() ) );
	}
}

update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', (int) $front_page_id );
update_option( 'page_for_posts', (int) $posts_page_id );
update_option( 'blogname', 'Nolan Young Automated Theme Test' );
flush_rewrite_rules();
