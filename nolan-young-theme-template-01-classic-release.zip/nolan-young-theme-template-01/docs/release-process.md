# Release process

A release is approved only when the source checks, deterministic package, exact-ZIP WordPress tests, and manual staging review all refer to the same archive.

## 1. Prepare a clean source checkout

1. Confirm there are no unintended source changes.
2. Synchronize the version in `style.css`, `package.json`, `package-lock.json`, `readme.txt`, translation metadata, and `CHANGELOG.md`.
3. Confirm `package-lock.json` and `composer.lock` contain only public, portable distribution URLs.
4. Install the locked dependencies:

```bash
npm ci
composer install
```

## 2. Run source gates

```bash
npm test
```

This enforces:

- JavaScript, Node helper, and SCSS linting.
- PHP syntax checks.
- Optimized asset compilation.
- Structural and architecture validation.
- Zero known npm vulnerabilities.
- WordPress Coding Standards and documentation rules.
- PHPCompatibilityWP for PHP 7.4 and newer.
- Source-level PHPUnit regression tests.

The CI matrix repeats source quality checks on PHP 7.4 and PHP 8.4.

## 3. Generate and verify the production archive

```bash
npm run package
```

Expected outputs:

```text
dist/nolan-young-theme-template-01.zip
dist/nolan-young-theme-template-01.zip.sha256
dist/release-manifest.json
```

The builder uses a sorted runtime allowlist and fixed timestamps. The verifier rejects any missing, extra, renamed, or byte-different file and requires one top-level theme directory.

## 4. Test the exact archive in clean WordPress

Docker must be running. Install Chromium once, then execute:

```bash
npx playwright install chromium
npm run release:verify
```

The verifier extracts the generated ZIP and tests that exact package in WordPress 7.0 on PHP 7.4. It runs WordPress integration tests, Theme Check, desktop/mobile Chromium tests, Axe accessibility checks, front-page block rendering, normal/wide/full alignment checks, overflow checks, and contextual-link checks.

## 5. Complete manual staging review

Install the checksum-matched ZIP on clean staging and review:

- Theme activation and deactivation.
- Front page with stored blocks and with the empty-content fallback.
- Posts index, search, archives, pagination, comments, 404, and privacy-policy templates.
- Keyboard navigation, focus visibility, screen-reader labels, and menu behavior.
- Responsive layouts in current Chrome, Firefox, Safari, and Edge.
- Companion-plugin integration paths.
- `WP_DEBUG` logs, caching, and production-host behavior.

Record the tested ZIP checksum. Do not rebuild after staging approval; any rebuild creates a new artifact that must be verified again.
