# Getting started

## Install the production theme

1. Install and activate `nolan-young-core.zip` when the site requires the companion plugin's content types or business features.
2. Install and activate `nolan-young-theme-template-01.zip`.
3. Assign Primary and Footer menus under **Appearance → Menus**.
4. Create a static front page and optional Posts page under **Settings → Reading**.
5. Add blocks to the assigned front page. Stored block content is rendered when present; the curated PHP composition remains the fallback for an empty front page.

## Prepare the source environment

From the source root, install both locked dependency sets:

```bash
npm ci
composer install
```

Use the readable WordPress asset watcher during normal development:

```bash
npm run start
```

Use the minified production-mode watcher only when production-style output is needed during local development:

```bash
npm run dev
```

Stop active watchers before release verification.

## Build, test, and package

```bash
npm run build
npm test
npm run package
```

- `npm run build` cleans generated assets, lints JavaScript/Node/SCSS, checks PHP syntax, compiles production assets, and validates release architecture.
- `npm test` adds the dependency audit, WordPress Coding Standards, PHPCompatibilityWP, and source-level PHPUnit tests.
- `npm run package` repeats all gates, creates the deterministic one-root production ZIP, and verifies byte-for-byte source/package parity.

To install and test the exact generated ZIP in clean WordPress 7.0/PHP 7.4 state, start Docker and run:

```bash
npx playwright install chromium
npm run release:verify
```
